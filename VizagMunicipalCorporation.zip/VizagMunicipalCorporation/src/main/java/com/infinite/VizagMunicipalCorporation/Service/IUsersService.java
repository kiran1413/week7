package com.infinite.VizagMunicipalCorporation.Service;

public interface IUsersService {

}
