package com.infinite.VizagMunicipalCorporation.Repository;

public interface IUsersDao {

}
