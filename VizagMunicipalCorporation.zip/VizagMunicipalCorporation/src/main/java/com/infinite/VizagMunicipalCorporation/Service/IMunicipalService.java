package com.infinite.VizagMunicipalCorporation.Service;

import java.util.List;

import com.infinite.VizagMunicipalCorporation.Model.Municipal;

public interface IMunicipalService {
	public List<Municipal> getAllComplains();

	public Municipal getMunicipal(int id);

	public Municipal addMunicipal(Municipal municipal);

	public void updateMunicipal(Municipal municipal);

	public void deleteMunicipal(int id);
}
