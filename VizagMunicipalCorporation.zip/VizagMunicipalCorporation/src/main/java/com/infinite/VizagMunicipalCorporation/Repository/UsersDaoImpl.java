package com.infinite.VizagMunicipalCorporation.Repository;

public class UsersDaoImpl {

}
