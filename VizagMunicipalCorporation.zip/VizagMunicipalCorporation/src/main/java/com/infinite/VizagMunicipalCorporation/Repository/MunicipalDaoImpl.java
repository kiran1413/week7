package com.infinite.VizagMunicipalCorporation.Repository;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.Hibernate;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infinite.VizagMunicipalCorporation.Model.Municipal;
//import com.mysql.cj.Session;


@Repository 
public class MunicipalDaoImpl implements IMunicipalDao {
	@Autowired
	private SessionFactory SessionFactory;

	public void setSessionFactory(Session sessionFactory) {
		this.SessionFactory = SessionFactory;
	}

	@Override
	public List<Municipal> getAllComplains() {
		// TODO Auto-generated method stub
		Session session = this.SessionFactory.getCurrentSession();
		List<Municipal> ls = session.createQuery("from Municipal").list();
		return ls;
	}

	@Override
	public Municipal getMunicipal(int id) {
		// TODO Auto-generated method stub
		Session session = this.SessionFactory.getCurrentSession();
		Municipal municipal = (Municipal) session.get(Municipal.class, id);
		return municipal;
	}

	@Override
	public Municipal addMunicipal(Municipal municipal) {
		// TODO Auto-generated method stub
		Session session = this.SessionFactory.getCurrentSession();
		session.save(municipal);
		return null;
	}

	@Override
	public void updateMunicipal(Municipal municipal) {
		// TODO Auto-generated method stub
		Session session = (Session) this.SessionFactory.getCurrentSession();
		Hibernate.initialize(municipal);
		session.update(municipal);
	}

	@Override
	public void deleteMunicipal(int id) {
		// TODO Auto-generated method stub
		Session session = this.SessionFactory.getCurrentSession();
		Municipal m = (Municipal) session.load(Municipal.class, new Integer(id));
		if (null != m) {
			session.delete(m);
		}
	}
}
