package com.infinite.VizagMunicipalCorporation.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.infinite.VizagMunicipalCorporation.Model.Municipal;
import com.infinite.VizagMunicipalCorporation.Service.MunicipalServiceImpl;
import com.infinite.VizagMunicipalCorporation.Service.UsersServiceImpl;

@Controller
public class MunicipalController {
	@Autowired
	MunicipalServiceImpl MunicipalServiceImpl;

	@Autowired
	UsersServiceImpl LoginServiceImpl;

	/*
	 * @RequestMapping(value = "/", method = RequestMethod.GET, headers =
	 * "Accept=application/json") public String goToHomePage() { return
	 * "redirect:/getAllComplains"; }
	 */

	@RequestMapping(value = "/getAllComplains", method = RequestMethod.GET, headers = "Accept=application/json")
	public String getAllComplains(Model m) {
		m.addAttribute("municipal", new Municipal());
		m.addAttribute("listOfComplains", MunicipalServiceImpl.getAllComplains());
		return "complaindetails";
	}

	@RequestMapping(value = "/addComplains", method = RequestMethod.POST, headers = "Accept=application/json")
	public String addComplains(@ModelAttribute("municipal") Municipal municipal) {
		if (municipal.getId() == 0) {
			MunicipalServiceImpl.addMunicipal(municipal);
		} else {
			MunicipalServiceImpl.updateMunicipal(municipal);
			;
		}
		return "redirect:/getAllComplains";
	}

	@RequestMapping(value = "/updateComplains/{id}")
	public String updateComplains(@PathVariable("id") int id, Model model) {
		model.addAttribute("municipal", this.MunicipalServiceImpl.getMunicipal(id));
		model.addAttribute("listOfComplains", this.MunicipalServiceImpl.getAllComplains());
		return "complaindetails";
	}

	@RequestMapping(value = "/deleteComplains/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public String deleteComplains(@PathVariable("id") int id) {
		MunicipalServiceImpl.deleteMunicipal(id);
		;
		return "redirect:/getAllComplains";
	}

	@RequestMapping(value = "/", method = RequestMethod.GET, headers = "Accept=application/json")
	public String goToHomePage() {
		return "login";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST, headers = "Accept=application/json")
	public String goToHomePage(@RequestParam String username) {

		int result = UsersServiceImpl.loginDeatils(username);
		if (result != 0) {
			return "redirect:/getAllComplains";
		}
		return null;
	}

}