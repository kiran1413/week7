package com.infinite.VizagMunicipalCorporation.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.infinite.VizagMunicipalCorporation.Model.Municipal;
import com.infinite.VizagMunicipalCorporation.Repository.MunicipalDaoImpl;

@Service
public class MunicipalServiceImpl {
	@Autowired
	MunicipalDaoImpl MunicipalDAOImpl;

	@Transactional
	public List<Municipal> getAllComplains() {
		// TODO Auto-generated method stub

		return MunicipalDAOImpl.getAllComplains();
	}

	@Transactional
	public Municipal getMunicipal(int id) {
		// TODO Auto-generated method stub
		return MunicipalDAOImpl.getMunicipal(id);
	}

	@Transactional
	public Municipal addMunicipal(Municipal municipal) {
		// TODO Auto-generated method stub
		return MunicipalDAOImpl.addMunicipal(municipal);
	}

	@Transactional
	public void updateMunicipal(Municipal municipal) {
		// TODO Auto-generated method stub
		MunicipalDAOImpl.updateMunicipal(municipal);
	}

	@Transactional
	public void deleteMunicipal(int id) {
		// TODO Auto-generated method stub
		MunicipalDAOImpl.deleteMunicipal(id);
	}
}
